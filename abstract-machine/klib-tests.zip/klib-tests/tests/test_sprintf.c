#include <klib.h>
#include <am.h>
#include <klib-macros.h>
#include <limits.h>
void test_sprintf(){
    int data[] = {
        0, 
        INT_MAX / 17, 
        INT_MAX, 
        INT_MIN, 
        INT_MIN + 1,
        UINT_MAX / 17, 
        INT_MAX / 17, 
        UINT_MAX
    };
    char ref[][30] = {
    	"0",
	"126322567",
	"2147483647",
	"-2147483648",
	"-2147483647",
	"252645135",
	"126322567",
	"-1",
    };
    char dut[64]={0};
    for (size_t i = 0; i < sizeof(data) / sizeof(data[0]); i++) {
			sprintf(dut,"%d",data[i]);
			if(strcmp(ref[i],dut)!=0)
				panic("Error\n");				
			
    }	
}
int main(){
    test_sprintf();
}
