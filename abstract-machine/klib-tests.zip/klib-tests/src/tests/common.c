#include "common.h"
void reset(uint8_t *data) {
  int i;
  for (i = 0; i < N; i++) {
    data[i] = i + 1;
  }
}

// 检查 [l, r) 区间中的值是否依次为 val, val + 1, val + 2...
void check_seq(uint8_t *data,int l, int r, int val) {
  int i;
  for (i = l; i < r; i++) {
    assert(data[i] == val + i - l);
  }
}

// 检查 [l, r) 区间中的值是否均为 val
void check_eq(uint8_t *data,int l, int r, int val) {
  int i;
  for (i = l; i < r; i++) {
    assert(data[i] == val);
  }
}
