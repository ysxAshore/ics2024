#include <klib.h>
#include <am.h>
#include <klib-macros.h>
#include "common.h"
static uint8_t data1[N];
static uint8_t data2[N];

void test_memcmp() {
    reset(data1);
    reset(data2);
    // 1. 全部相同
    int result = memcmp(data1, data2, N);
    assert(result == 0);     // 检查是否为相同内容

    // 2. 部分相同，尾部不同
    data2[N - 1] = 0;        // 修改 data2 的最后一个字节
    result = memcmp(data1, data2, N);
    assert(result > 0);      // data1 最后一个字节 32 > data2 最后一个字节 0
    // 3. 开头不同
    data2[0] = 0;            // 修改 data2 的第一个字节
    result = memcmp(data1, data2, N);
    assert(result > 0);      // data1 第一个字节 1 > data2 第一个字节 0

    // 4. 中间不同
    data2[0] = 1;            // 恢复第一个字节
    data2[15] = 100;         // 修改中间字节
    result = memcmp(data1, data2, N);
    assert(result < 0);      // data1 第16个字节 16 < data2 第16个字节 100

    // 5. 比较前0~14
    result = memcmp(data1, data2, N / 2-1);
    assert(result == 0);     // 前0~14相同
}
