#include <klib.h>
#include <am.h>
#include <klib-macros.h>
#include "common.h"
static uint8_t data[N];

void test_memset() {
  int l, r;
  for (l = 0; l < N; l ++) {
    for (r = l + 1; r <= N; r ++) {
      reset(data);
      uint8_t val = (l + r) / 2;
      memset(data + l, val, r - l);
      check_seq(data,0, l, 1);
      check_eq(data,l, r, val);
      check_seq(data,r, N, r + 1);
    }
  }
}
