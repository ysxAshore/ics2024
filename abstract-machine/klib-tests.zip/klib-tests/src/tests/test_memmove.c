#include <klib.h>
#include <am.h>
#include <klib-macros.h>
#include "common.h"
static uint8_t data[N];

// 测试 memmove
void test_memmove() {
    reset(data);

    // 1. 非重叠区域测试
    memmove(data + 8, data, 8);  // 将前8个字节复制到位置8开始
    check_seq(data,8, 16, 1);         // 验证复制区域

    // 2. 目标在源后，存在部分重叠
    reset(data);
    memmove(data + 4, data, 12); // 将前12个字节复制到位置4开始
    check_seq(data,4, 16, 1);         // 验证数据没有因重叠被破坏

    // 3. 目标在源前，存在部分重叠
    reset(data);
    memmove(data, data + 4, 12); // 从位置4复制到开始位置
    check_seq(data,0, 12, 5);         // 验证数据没有因重叠被破坏
}

