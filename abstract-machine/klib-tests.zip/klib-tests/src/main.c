#include <amtest.h>

void (*entry)() = NULL; // mp entry

//static const char *tests[256] = {
//  ['s'] = "memset test",
//  ['h'] = "print help message",
//};
void test_memset();
void test_memmove();
void test_memcpy();
void test_memcmp();
void test_sprintf();
int main(const char *args) {
	//switch(args[0]){
		//CASE('s',test_memset);
	//}
	test_memset();
	test_memmove();
	test_memcpy();
	test_memcmp();
	test_sprintf();
  return 0;
}
